{\rtf1\ansi\ansicpg1252\cocoartf1561\cocoasubrtf200
{\fonttbl\f0\fmodern\fcharset0 Courier;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue0;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c0;}
\paperw11900\paperh16840\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\partightenfactor0

\f0\fs26 \cf0 \expnd0\expndtw0\kerning0
# Imatge hostservices:base\
## @edt ASIX-M11 Curs 2017-2018\
Creaci\'f3 de la imatge **hostservices:base**\
\
Imatge base fedora:24 amb serveis de xarxa. Cont\'e9 activats tant serveis standalone com xinetd.\
\
serveis (port,transport)\
\
 * xinetd:\
   * echo     (7, tcp, udp)\
   * discard  (9,tcp, udp)\
   * daytime  (13, tcp, udp)\
   * chargen  (19, tcp, udp)\
   * time     (37, tcp, udp)\
   * ipop3    (110, tcp)\
   * pop3s    (995, tcp)\
   * imap     (143, tcp)\
   * imaps    (993, tcp)\
\
   * daytime-bis (2013, tcp, redirect localhost:13)\
   * echo-bis    (2007, tcp, redirect localhost:7)\
   * http-switch (2080, tcp, redirect localhost:80)\
\
\
 * httpd  (80,tcp)\
 * vsftpd (20,21, tcp)\
 * tftp   (69, udp)\
 * smtp   (25, tcp)\
 * ssh    (22, tcp)\
 * telnet (23, tcp)\
\
}